﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum blocktype {
    OBSTACLE,
    WAYPOINT,
    GOAL
}

[RequireComponent(typeof(Collider))]
public class ReactiveBlock : MonoBehaviour {
    Collider cd;
    Renderer rd;
    public blocktype block;

    public AudioClip Waypoint;
    public AudioClip Obstacle;

    private bool active = true;

    // Use this for initialization
    void Start () {
        cd = GetComponent<Collider>();
        cd.isTrigger = true;
        rd = GetComponent<Renderer>();
    }

    public void Activate() {
        this.active = true;
    }

    public void Deactivate() {
        this.active = false;
    }

    void OnTriggerEnter(Collider other) {
        if(other.tag == "MainCamera" && active) {
            switch(block) {
                case blocktype.GOAL:
                    Debug.Log("You did it!");
                    break;
                case blocktype.OBSTACLE:
                    other.GetComponent<AudioSource>().PlayOneShot(this.Obstacle, 1.0f);
                    rd.material.color = Color.red;
                    break;
                case blocktype.WAYPOINT:
                    other.GetComponent<AudioSource>().PlayOneShot(this.Waypoint, 1.0f);
                    rd.material.color = Color.blue;
                    break;
            }
            Deactivate();
        }
    }
}
