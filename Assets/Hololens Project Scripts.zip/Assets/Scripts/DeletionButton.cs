﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using HoloToolkit.Unity.InputModule;

public class DeletionButton : MonoBehaviour, IInputClickHandler {
    private CourseObjectCollection parent;

    void Start() {
        parent = GameObject.Find("Game Manager").GetComponent<CourseObjectCollection>();
    }
    
    // TODO: Find the object to delete even if it's currently selected
    public void OnInputClicked(InputClickedEventData eventData) {
        GameObject obj = parent.GetSelectedObject();
        ReactiveBlock block = obj.GetComponent<ReactiveBlock>();
        if (obj == null) {
            return;
        }
        if(block.block == blocktype.WAYPOINT) {
            parent.RemoveWaypoint(block);
        }
        Destroy(obj);
    }
}
