﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class CourseObjectCollection : MonoBehaviour {
    private GameObject selectedObject = null;

    // ONLY FOR WAYPOINTS {
        private LineRenderer beam;
    // }
    private List<ReactiveBlock> waypointList = new List<ReactiveBlock>();

    public void Start() {
        beam = GetComponent<LineRenderer>();
    }

    public void AddWaypointToChain(ReactiveBlock bl) {
        waypointList.Add(bl);
        FixWaypointChain();
    }

    public void RemoveWaypoint(ReactiveBlock bl) {
        waypointList.Remove(bl);
        FixWaypointChain();
    }
    
    public void FixWaypointChain() {
        beam.SetVertexCount(waypointList.Count);
        int count = 0;
        foreach (var waypoint in waypointList) {
            beam.SetPosition(count, waypoint.transform.position);
            count++;
        }
    }

    public GameObject GetSelectedObject() {
        GameObject output = this.selectedObject;
        this.selectedObject = null;
        return output;
    }

    public void SetSelectedObject(GameObject selection) {
        selectedObject = selection;
    }
}
