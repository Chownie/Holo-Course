# Microsoft Selawik
Selawik is an open source replacement for Segoe UI. 

# Known open issues:
* Selawik is missing kerning to match Segoe UI. 
* Selawik needs improved hinting. 

[Microsoft's Open Source Fonts](https://github.com/Microsoft/fonts)
